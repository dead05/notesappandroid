package com.lguipeng.notes.injector.module;

import dagger.Module;


@Module
public class FragmentModule {
    public FragmentModule() {
    }
}
