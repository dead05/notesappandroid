package com.lguipeng.notes.mvp.views;

/**
 * Created by lgp on 2015/9/4.
 */
public interface View {
}
